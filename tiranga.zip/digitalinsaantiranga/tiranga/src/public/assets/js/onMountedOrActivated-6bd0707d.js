import{B as n,ac as e,bm as o}from"./vendor-b2024301.js";function c(t){let a;n(async()=>{t(),await e(()=>{a=!0})}),o(()=>{a&&t()})}export{c as o};
